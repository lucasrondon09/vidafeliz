<?php

return [
	'invalidCellMethod'     => '{class}::{method} não é um método válido."',
	'missingCellParameters' => '{class}::{method} não possui parâmetros.',
	'invalidCellParameter'  => '{0} não é um nome de parâmetro válido.',
	'noCellClass'           => 'Nenhuma classe de view cell fornecida.',
	'invalidCellClass'      => 'Não é possível localizar a classe view cell: {0}.',
	'tagSyntaxError'        => 'Você tem um erro de sintaxe nas tags do Parser: {0}',
];
