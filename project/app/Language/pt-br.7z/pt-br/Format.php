<?php

return [
	'invalidJSON'      => 'Falha ao analisar a string json, erro: "{0}".',
	'missingExtension' => 'A extensão SimpleXML é necessária para formatar XML.',
];
