<?php

return [
	'invalidLogLevel' => '{0} é um level de log inválido.',
];
